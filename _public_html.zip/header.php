<div style="text-align:center; ">
<a href="https://sattaking.chat"><img height="100" style="margin-bottom: -15px; margin-top: -8px;" src="images/logo.webp" alt="satta"></a>

</div>
<div class="w-100 mt-1">
<center><a class="btn" href="javascript: document.body.scrollIntoView(false);">Go to Bottom</a></center>
</div>